from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.regularizers import l2

models = {}

models['agriculture'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(16, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(32, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(32, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(12, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['furniture'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(28, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(42, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(42, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(56, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(63, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(63, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(56, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(42, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(42, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(21, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['underwear'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(56, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(84, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(84, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(112, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(126, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(126, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(112, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(84, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(84, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(42, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )


models['beauty'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(32, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(64, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(64, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )


models['life'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(36, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(81, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(81, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(27, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )


models['clothing'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(40, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(60, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(60, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(80, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(80, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(60, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(60, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(30, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['accessory'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(16, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(32, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(32, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(24, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(12, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['bedding'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(24, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(54, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(48, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(18, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['appliance'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(48, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(96, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(108, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(108, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(96, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(72, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(36, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['health'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(60, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(120, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(135, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(135, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(120, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(90, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )

models['kitchen'] = keras.Sequential(
            [
                layers.BatchNormalization(),
                layers.Dense(44, activation='relu', name='hidden_layer1', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(66, activation='relu', name='hidden_layer2',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(66, activation='relu', name='hidden_layer3', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(88, activation='relu', name='hidden_layer4',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(99, activation='relu', name='hidden_layer5',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(99, activation='relu', name='hidden_layer6', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(88, activation="relu", name="hidden_layer7",
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(66, activation='relu', name='hidden_layer8', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(66, activation='relu', name='hidden_layer9', kernel_regularizer=l2(0.01),
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(33, activation='relu', name='hidden_layer10',
                             kernel_initializer=keras.initializers.HeNormal()),
                layers.Dense(1, activation=None, name="output_layer", kernel_initializer=keras.initializers.HeNormal())
            ]
        )