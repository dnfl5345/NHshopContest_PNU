def scaling_negative(criteria, data):
    import numpy as np
    from sklearn.preprocessing import MinMaxScaler

    scaler = MinMaxScaler()
    for col in criteria.columns:
        if criteria.corr().loc[col, '취급액'] >=0 or col =='취급액':
            continue
        data[col] = (1 / (data[col] + 1e-3)).apply(np.log)
        data[col] = scaler.fit_transform(data[col].values.reshape(-1, 1)).ravel()
    return data

def make_interaction(train_path="", submission_path ="sub_", output_path="sub_"):
    '''
    :param train_path: 모델을 학습할 때 사용한 파일(file_final.csv)이 저장된 경로.
    :param submission_path: merge_scaling_dt의 결과로 생성된 파일이 저장된 경로.
    :param output_path: 예측할 때 사용할 file_final.csv파일이 저장된 경로
    :output: train_set에서와 동일한 방식으로 merge_scaling_dt로 만든 파일에 feature interaction 적용 후, file_final.csv형식으로 저장.
    '''
    '''
    train data에서 사용했던 feature interaction방식과 동일하게 submit 파일에 적용
    '''
    import pandas as pd

    files = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
             'life', 'underwear']
    for file in files:
        train_data = pd.read_csv(train_path + file + '_final.csv', index_col='Unnamed: 0')
        submission_data = pd.read_csv(submission_path + file + '3.csv', index_col='Unnamed: 0')
        temp_data = pd.read_csv(train_path + file + '3.csv', index_col='Unnamed: 0')

        submission_data.drop(columns=['방송일시', '노출(분)', '마더코드', '상품코드', '상품명', '상품군'], inplace=True)
        temp_data.drop(columns=['방송일시', '노출(분)', '마더코드', '상품코드', '상품명', '상품군'], inplace=True)

        submission_data = scaling_negative(temp_data, submission_data)

        for train_col in train_data.columns:
            if train_col.find('+') != -1:
                interaction_cols = train_col.split('+')
                temp = submission_data[interaction_cols].sum(axis=1)
                submission_data[train_col] = temp

        cols = train_data.drop(columns=['취급액']).columns
        submission_data = submission_data[cols]

        submission_data.to_csv(output_path + file + '_final.csv', index=True)

if __name__ == '__main__':
    make_interaction()