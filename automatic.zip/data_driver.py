def preprocessing_data():
    '''
    학습 데이터 생성
    '''
    from add_date_feature import add_date_feature
    from dt_clustering import clustering
    from add_specified_feature import add_specified_feature
    from dt_scaling import data_scaling
    from feature_interaction import feature_interaction

    print("Add date feature")
    add_date_feature()
    print("Clustering")
    clustering()
    print("Add specified feature")
    add_specified_feature()
    print("Data scaling")
    data_scaling()
    print("Do feature interaction")
    feature_interaction()

if __name__ == '__main__':
    preprocessing_data()
