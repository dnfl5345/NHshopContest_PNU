def make_submission(submission_file = '2020 빅콘테스트 데이터분석분야-챔피언리그_2020년 6월 판매실적예측데이터(평가데이터).xlsx', train_path="", target_path="sub_"):
    '''
    제출 파일 생성
    '''
    import pandas as pd
    from add_date_feature import add_date_feature
    from dt_clustering import clustering
    from add_specified_feature import add_specified_feature
    from merge_scaling_dt import merge_scaling_dt
    from make_interaction import make_interaction
    from best_performance_model import best_performance_model
    from sklearn.model_selection import train_test_split
    from tqdm import tqdm
    import model_info

    add_date_feature(file_name='2020 빅콘테스트 데이터분석분야-챔피언리그_2020년 6월 판매실적예측데이터(평가데이터).xlsx', output_path='sub_dt2.csv')
    clustering(input_path='sub_dt2.csv', output_path='sub_')
    add_specified_feature(input_path='sub_', output_path='sub_')
    merge_scaling_dt()
    make_interaction()

    files = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
             'life', 'underwear']
    target_file = pd.read_excel(submission_file, skiprows=1)
    models = {}
    hists = {}
    for file in tqdm(files):
        print("predicting " + file)
        train_data = pd.read_csv(train_path + file + '_final.csv', index_col='Unnamed: 0')

        train, test = train_test_split(train_data, test_size=0.2, shuffle=True)
        train_label = train['취급액']
        test_label = test['취급액']
        train.drop(columns=['취급액'], inplace=True)
        test.drop(columns=['취급액'], inplace=True)
        models[file], hists[file] = best_performance_model(model_info.models[file], train, train_label, test, test_label)
        target = pd.read_csv(target_path + file + '_final.csv', index_col='Unnamed: 0')
        target_file.loc[target.index, '취급액'] = models[file].predict(target).ravel()
    target_file.to_csv('submission.csv', index=True)
    return models, hists
if __name__ == '__main__':
    make_submission()