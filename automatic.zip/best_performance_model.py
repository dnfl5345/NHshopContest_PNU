def best_performance_model(base_model, X, Y, val_X, val_Y):
    from tqdm.keras import TqdmCallback
    from tensorflow import keras
    from tqdm import tqdm
    import tensorflow as tf

    early_stopping = keras.callbacks.EarlyStopping(monitor='val_loss', mode='min', patience=200)
    models = [keras.models.clone_model(base_model) for i in range(5)]
    for i in range(5):
        models[i].compile(loss=tf.keras.losses.MeanAbsolutePercentageError(),
                    optimizer=keras.optimizers.Adam(clipnorm=1.2),
                    metrics=[tf.keras.metrics.MeanAbsoluteError(), tf.keras.metrics.MeanAbsolutePercentageError(), tf.keras.metrics.RootMeanSquaredError()])
    best_model = models[0]
    best_hist = None
    for i in tqdm(range(5)):
        hist = models[i].fit(X, Y, epochs=30000, batch_size=4048,
                             validation_data=(val_X, val_Y), verbose=0,
                             callbacks=[TqdmCallback(verbose=0), early_stopping])
        if models[i].evaluate(val_X, val_Y)[2] <= best_model.evaluate(val_X, val_Y)[2]:
            best_model = models[i]
            best_hist = hist

    return best_model, best_hist