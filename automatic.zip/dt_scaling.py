def boolean_to_int(data):
    '''
    boolean columns to int columns
    '''
    data.loc[:, '휴일변수'] = data.loc[:, '휴일변수'].astype(int)
    data.loc[:, '주말변수'] = data.loc[:, '주말변수'].astype(int)
    data.loc[:, '월급일변수'] = data.loc[:, '월급일변수'].astype(int)
    data.loc[:, '연속휴일변수'] = data.loc[:, '연속휴일변수'].astype(int)
    data.loc[:, '반기별변수'] = data.loc[:, '반기별변수'].astype(int)

    return data
def processing_zero_or_nan(data):
    '''
    취급액이 0이거나 nan value인 경우 처리
    '''
    import numpy as np
    mask = np.isnan(data['취급액'] + 1)
    data.drop(data[mask].index, inplace=True)
    mask = (data['취급액'] < data['판매단가']) & (data['취급액'] == 50000)
    data.loc[mask, '취급액'] = 0

    return data
def add_time_columns(data, output):
    '''
    방송 시간대에 따른 가중치 부여
    '''
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import MinMaxScaler

    m1 = []
    for i in range(10):
        m1.append('0' + str(i))
    for i in range(10, 20):  # 10,20
        m1.append(str(i))
    m2 = []
    for i in range(20, 40):
        m2.append(str(i))
    m3 = []
    for i in range(40, 60):
        m3.append(str(i))

    hours = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17',
             '18', '19', '20', '21', '22', '23']

    data['시간/분'] = np.nan
    for hour in hours:
        for minute in m1:
            data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '00'
        for minute in m2:
            data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '20'
        for minute in m3:
            data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '40'

    temp = []
    time = []
    for hour in hours:
        for minute in m1:
            if not (np.isnan(np.mean(data[data['시간/분'] == hour + minute]['취급액']) + 1)):
                time.append(hour + minute)
                temp.append(np.mean(data[data['시간/분'] == hour + minute]['취급액']))
        for minute in m2:
            if not (np.isnan(np.mean(data[data['시간/분'] == hour + minute]['취급액']) + 1)):
                time.append(hour + minute)
                temp.append(np.mean(data[data['시간/분'] == hour + minute]['취급액']))
        for minute in m3:
            if not (np.isnan(np.mean(data[data['시간/분'] == hour + minute]['취급액']) + 1)):
                time.append(hour + minute)
                temp.append(np.mean(data[data['시간/분'] == hour + minute]['취급액']))
    scaler = MinMaxScaler()
    temp = np.array(temp)
    temp = temp.reshape((-1, 1))
    scaler.fit(temp.reshape(-1, 1))
    norm = scaler.transform(temp)
    temp_df = pd.DataFrame(norm, index=time)
    temp_df.reset_index(inplace=True)
    temp_df.rename(columns={'index': '시간대', 0: '시간대 스케일링'}, inplace=True)

    data['시간대'] = 0
    for i in range(len(temp_df)):
        data.loc[data['시간/분'] == temp_df.loc[i, '시간대'], '시간대'] = temp_df.loc[i, '시간대 스케일링']
    temp_df.to_csv(output + '_time.csv', index=True)
    data.drop(columns='시간/분', inplace=True)

    return data
def add_succesive(data, output):
    '''
    연속 방영 횟수에 따른 가중치 column 생성
    '''
    import pandas as pd
    import numpy as np
    from sklearn.preprocessing import MinMaxScaler

    scaler = MinMaxScaler()
    temp = {'연속방영 가중치': [0]}
    for i in range(1, data.shape[0]):
        if (data.iloc[i - 1]['마더코드'] == data.iloc[i]['마더코드']) & (data.iloc[i - 1, 0] == data.iloc[i, 0]):
            temp['연속방영 가중치'].append(temp['연속방영 가중치'][i - 1])
        elif data.iloc[i - 1]['마더코드'] == data.iloc[i]['마더코드']:
            temp['연속방영 가중치'].append(temp['연속방영 가중치'][i - 1] + 1)
        else:
            temp['연속방영 가중치'].append(0)
    temp['연속방영 가중치'] = np.array(temp['연속방영 가중치'])

    temp = pd.DataFrame(temp)

    data['연속방영 가중치'] = temp['연속방영 가중치']

    ss = []
    for i in range(8):
        ss.append(np.mean(data.loc[data['연속방영 가중치'] == i, '취급액']))
    ss[6] = np.mean(ss[:6])
    ss[7] = np.mean(ss[:6])
    ss = np.array(ss).reshape((-1, 1))
    scaler.fit(ss)
    ss = scaler.transform(ss)
    ttt_df = {'연속방영': [i for i in range(6)], '연속방영 스케일링': [ss[i][0] for i in range(6)]}
    temp_df = pd.DataFrame(ttt_df)

    for i in range(6):
        data.loc[data['연속방영 가중치'] == i, '연속방영 가중치'] = ss[i][0]

    mask = np.isnan(data['연속방영 가중치'] + 1)
    data.loc[mask, '연속방영 가중치'] = 0
    temp_df.to_csv(output + '_successive.csv', index=True)

    return data
def price_scaling(data):
    '''
    판매단가 스케일링
    '''
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    temp = data['판매단가'].values.reshape((-1, 1))
    temp = scaler.fit_transform(temp.reshape(-1, 1))

    data['판매단가'] = temp

    return data
def add_month(data, output):
    '''
    취급액에 따른 월별 가중치 부여
    '''
    import pandas as pd
    import numpy as np
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()

    data['방송일시'] = data['방송일시'].apply(pd.to_datetime)
    data['월'] = data['방송일시'].dt.month
    temp = data['취급액'].groupby(data['월']).mean()

    m = temp
    temp = m.values.reshape((-1, 1))
    temp = scaler.fit_transform(temp.reshape(-1, 1))
    months = data['월'].unique().tolist()
    i = 0
    while (i < len(months)):
        if np.isnan(months[i] + 1):
            del months[i]
            continue
        i = i + 1

    ttt_df = {'월': [i for i in months], '월 스케일링': [temp[i][0] for i in range(len(months))]}
    temp_df = pd.DataFrame(ttt_df)

    j = 0
    for i in m.index:
        m[i] = temp[j]
        j = j + 1
    temp = m
    temp = temp.reset_index()
    for i in range(len(temp)):
        data.loc[data['월'] == temp.loc[i, '월'], '월'] = temp.loc[i, '취급액']

    temp_df.to_csv(output + '_month.csv', index=True)
    return data

def add_brand(data, output):
    '''
    취급액에 따른 브랜드별 가중치 부여
    '''
    import pandas as pd
    from sklearn.preprocessing import MinMaxScaler

    scaler = MinMaxScaler()

    temp = data['취급액'].groupby(data['브랜드']).mean()
    b = temp
    temp = b.values.reshape((-1, 1))
    temp = scaler.fit_transform(temp.reshape(-1, 1))
    temp_df = pd.DataFrame(temp.ravel(), index=b.index)
    temp_df.reset_index(inplace=True)
    temp_df.rename(columns={0: '브랜드 스케일링', 'index' : '브랜드'}, inplace=True)

    j = 0
    for i in b.index:
        b[i] = temp[j]
        j = j + 1
    temp = b
    temp = temp.reset_index()
    for i in range(len(temp)):
        data.loc[data['브랜드'] == temp.loc[i, '브랜드'], '브랜드'] = temp.loc[i, '취급액']
    temp_df.to_csv(output + '_brand.csv', index=True)
    return data

def add_kind(data, output):
    '''
    취급액에 따른 상품종류별 가중치 부여
    '''
    import pandas as pd
    from sklearn.preprocessing import MinMaxScaler

    scaler = MinMaxScaler()

    temp = data['취급액'].groupby(data['상품종류']).mean()
    k = temp
    temp = k.values.reshape((-1, 1))
    temp = scaler.fit_transform(temp.reshape(-1, 1))
    temp_df = pd.DataFrame(temp.ravel(), index=k.index)
    temp_df.reset_index(inplace=True)
    temp_df.rename(columns={0: '상품종류 스케일링', 'index' : '상품종류'}, inplace=True)

    j = 0
    for i in k.index:
        k[i] = temp[j]
        j = j + 1
    temp = k
    temp = temp.reset_index()
    for i in range(len(temp)):
        data.loc[data['상품종류'] == temp.loc[i, '상품종류'], '상품종류'] = temp.loc[i, '취급액']
    temp_df.to_csv(output + '_kind.csv', index=True)
    return data

def add_gender(data, output):
    '''
    취급액에 따른 성별별 가중치 부여
    '''
    import pandas as pd
    temp = data['취급액'].groupby(data['성별']).mean()
    g = temp
    g = (g - g.mean()) / (g.max() - g.min()) + 0.7
    temp = g
    temp = temp.reset_index()

    temp_df = pd.DataFrame(temp['취급액'].values, index=temp['성별'].values)
    temp_df.reset_index(inplace=True)
    temp_df.rename(columns={0: '성별 스케일링', 'index':'성별'}, inplace=True)

    for i in range(len(temp)):
        data.loc[data['성별'] == temp.loc[i, '성별'], '성별'] = temp.loc[i, '취급액']
    temp_df.to_csv(output + '_gender.csv', index=True)
    return data

def add_payment(data, output):
    '''
    취급액에 따른 결제방식별 가중치 부여
    '''
    import pandas as pd

    temp = data['취급액'].groupby(data['결제방식']).mean()
    p = temp
    p = (p - p.mean()) / (p.max() - p.min()) + 0.5
    temp = p
    temp = temp.reset_index()

    temp_df = pd.DataFrame(temp['취급액'].values, index=temp['결제방식'].values)
    temp_df.reset_index(inplace=True)
    temp_df.rename(columns={0: '결제방식 스케일링', 'index' : '결제방식'}, inplace=True)

    for i in range(len(temp)):
        data.loc[data['결제방식'] == temp.loc[i, '결제방식'], '결제방식'] = temp.loc[i, '취급액']
    temp_df.to_csv(output + '_pay.csv',index=True)
    return data

def data_scaling(input_path = './', output_path = './'):
    '''
    :param input_path: add_specified_feature.py의 실행결과로 생성된 파일의 위치
    :param output_path: 출력할 파일의 경로
    :output: 각 파일별로 전치리 및 스케일링 한 후, file + 3.csv 형식으로 저장. file_*.csv 파일은 train_set에서 가중치를 부여했던
             정보를 저장해 모델 학습 후, 예측할 때 동일한 가중치를 부여하기 위해 저장.
    '''
    import pandas as pd
    files = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
             'life', 'underwear']

    brand = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'furniture', 'health', 'kitchen', 'underwear']
    kind = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
            'life', 'underwear']
    pay = ['appliance', 'furniture', 'health']

    for file in files:
        data = pd.read_csv(input_path + file + '2.csv', index_col='Unnamed: 0')

        data.reset_index(inplace=True)
        data.rename(columns={'index': 'Unnamed: 0'}, inplace=True)

        data = boolean_to_int(data)

        data = processing_zero_or_nan(data)

        data = add_time_columns(data, output_path + file)
        data = add_succesive(data, output_path + file)
        data = price_scaling(data)
        data = add_month(data, output_path + file)

        if file in brand:
            data = add_brand(data, output_path + file)

        if file in kind:
            data = add_kind(data, file)

        if file == 'underwear':
            data = add_gender(data, output_path + file)

        if file in pay:
            data = add_payment(data, output_path + file)

        data.set_index('Unnamed: 0', inplace=True)
        data.to_csv(output_path + file + '3.csv', index=True)