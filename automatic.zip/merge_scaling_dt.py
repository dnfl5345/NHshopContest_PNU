def merge_scaling_dt(input_path="sub_", info_path="", output_path="sub_"):
    '''
    :param input_path: dt_clustering의 clustering 함수의 결과에 따라 생성된 file2.csv파일이 저장되어있는 경로
    :param info_path: 가중치에 관한 정보가 저장된 file_*.csv파일이 저장되어있는 경로
    :param output_path: file3.csv파일을 저장할 경로
    :output: file_*.csv 파일에서 가중치를 어떻게 부여할지 읽어들여, file2.csv파일에서 읽어들인 data에
             각 가중치 별, column을 추가한 후에, file3.csv로 저장.
    '''
    import pandas as pd
    import numpy as np

    files = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
             'life', 'underwear']

    brand = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'furniture', 'health', 'kitchen', 'underwear']
    kind = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
            'life', 'underwear']
    pay = ['appliance', 'furniture', 'health']

    for file in files:
        data = pd.read_csv(input_path + file + '2.csv', index_col='Unnamed: 0')

        data.reset_index(inplace=True)

        data.loc[:, '휴일변수'] = data.loc[:, '휴일변수'].astype(int)
        data.loc[:, '주말변수'] = data.loc[:, '주말변수'].astype(int)
        data.loc[:, '월급일변수'] = data.loc[:, '월급일변수'].astype(int)
        data.loc[:, '연속휴일변수'] = data.loc[:, '연속휴일변수'].astype(int)
        data.loc[:, '반기별변수'] = data.loc[:, '반기별변수'].astype(int)

        data.rename(columns={'index': 'Unnamed: 0'}, inplace=True)

        m1 = []
        for i in range(10):
            m1.append('0' + str(i))
        for i in range(10, 20):  # 10,20
            m1.append(str(i))
        m2 = []
        for i in range(20, 40):
            m2.append(str(i))
        m3 = []
        for i in range(40, 60):
            m3.append(str(i))

        hours = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16',
                 '17',
                 '18', '19', '20', '21', '22', '23']

        data['시간/분'] = np.nan
        for hour in hours:
            for minute in m1:
                data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '00'
            for minute in m2:
                data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '20'
            for minute in m3:
                data.loc[data.방송일시.str.contains(r'\s' + hour + ':' + minute), '시간/분'] = hour + '40'

        time_info = pd.read_csv(info_path + file + '_time.csv')
        time_info['시간대'] = time_info['시간대'].astype(str)

        data['시간대'] = 0
        for i in range(len(time_info)):
          data.loc[data['시간/분'] == time_info.loc[i, '시간대'], '시간대'] = time_info.loc[i, '시간대 스케일링']
        data.drop(columns='시간/분', inplace=True)

        temp = {'연속방영 가중치': [0]}
        for i in range(1, data.shape[0]):
            if (data.iloc[i - 1]['마더코드'] == data.iloc[i]['마더코드']) & (data.iloc[i - 1, 0] == data.iloc[i, 0]):
                temp['연속방영 가중치'].append(temp['연속방영 가중치'][i - 1])
            elif data.iloc[i - 1]['마더코드'] == data.iloc[i]['마더코드']:
                temp['연속방영 가중치'].append(temp['연속방영 가중치'][i - 1] + 1)
            else:
                temp['연속방영 가중치'].append(0)
        temp['연속방영 가중치'] = np.array(temp['연속방영 가중치'])

        temp = pd.DataFrame(temp)

        data['연속방영 가중치'] = np.nan
        data['연속방영'] = temp['연속방영 가중치']
        succ_info = pd.read_csv(info_path + file + '_successive.csv')

        for i in range(len(succ_info)):
            data.loc[data['연속방영'] == succ_info.loc[i,'연속방영'], '연속방영 가중치'] = succ_info.loc[i,'연속방영 스케일링']
        data.loc[data['연속방영'] == 6, '연속방영 가중치'] = np.mean(succ_info['연속방영 스케일링'])
        data.loc[data['연속방영'] == 7, '연속방영 가중치'] = np.mean(succ_info['연속방영 스케일링'])
        data.drop(columns=['연속방영'],inplace=True)

        from sklearn.preprocessing import MinMaxScaler
        scaler = MinMaxScaler()
        scaler.fit(pd.read_csv(info_path + file + '2.csv', index_col='Unnamed: 0')['판매단가'].values.reshape(-1,1))
        data['판매단가'] = scaler.transform(data['판매단가'].values.reshape(-1,1)).ravel()

        data['방송일시'] = data['방송일시'].apply(pd.to_datetime)
        data['월'] = data['방송일시'].dt.month

        month_info = pd.read_csv(info_path + file + '_month.csv')
        data['월 가중치'] = month_info['월 스케일링'].mean()
        for i in range(len(month_info)):
            data.loc[data['월'] == month_info.loc[i,'월'],'월 가중치'] = month_info.loc[i, '월 스케일링']
        data.drop(columns=['월'], inplace=True)
        data.rename(columns={'월 가중치':'월'},inplace=True)

        if file in brand:
            brand_info = pd.read_csv(info_path + file + '_brand.csv')
            data['브랜드 가중치'] = brand_info['브랜드 스케일링'].mean()
            for i in range(len(brand_info)):
                data.loc[data['브랜드'] == brand_info.loc[i, '브랜드'], '브랜드 가중치'] = brand_info.loc[i, '브랜드 스케일링']
            data.drop(columns=['브랜드'], inplace=True)
            data.rename(columns={'브랜드 가중치':'브랜드'}, inplace=True)

        if file in kind:
            kind_info = pd.read_csv(info_path + file + '_kind.csv')
            data['상품종류 가중치'] = kind_info['상품종류 스케일링'].mean()
            for i in range(len(kind_info)):
                data.loc[data['상품종류'] == kind_info.loc[i, '상품종류'], '상품종류 가중치'] = kind_info.loc[i, '상품종류 스케일링']
            data.drop(columns=['상품종류'], inplace=True)
            data.rename(columns={'상품종류 가중치': '상품종류'}, inplace=True)

        if file == 'underwear':
            gender_info = pd.read_csv(info_path + file + '_gender.csv')
            data['성별 가중치'] = gender_info['성별 스케일링'].mean()
            for i in range(len(gender_info)):
                data.loc[data['성별'] == gender_info.loc[i, '성별'], '성별 가중치'] = gender_info.loc[i, '성별 스케일링']
            data.drop(columns=['성별'], inplace=True)
            data.rename(columns={'성별 가중치':'성별'}, inplace=True)

        if file in pay:
            pay_info = pd.read_csv(info_path + file + '_pay.csv')
            data['결제방식 가중치'] = pay_info['결제방식 스케일링'].mean()
            for i in range(len(pay_info)):
                data.loc[data['결제방식'] == pay_info.loc[i, '결제방식'], '결제방식 가중치'] = pay_info.loc[i, '결제방식 스케일링']
            data.drop(columns=['결제방식'], inplace=True)
            data.rename(columns={'결제방식 가중치': '결제방식'}, inplace=True)


        data.set_index('Unnamed: 0', inplace=True)
        data.to_csv(output_path + file + '3.csv', index=True)
if __name__ == '__main__':
    merge_scaling_dt(input_path='automatic/sub_',info_path='automatic/', output_path='automatic/sub_')