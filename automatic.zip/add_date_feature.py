def add_date_feature(input_path = "",\
                     file_name = "2020 빅콘테스트 데이터분석분야-챔피언리그_2019년 실적데이터_v1_200818.xlsx",\
                     output_path = 'dt2.csv'):
    '''
    :param input_path: 입력 파일 경로 
    :param file_name: 입력 파일 명
    :param output_path: 출력파일 경로 및 이름
    :output: 입력파일에 날짜 관련 데이터 추가 후에 output_path에 저장
    '''
    import pandas as pd
    import datetime
    import requests
    from bs4 import BeautifulSoup

    dt = datetime.datetime.now()
    data = pd.read_excel(input_path + file_name, skiprows = 1)

    year = '2020'
    mykey = 'H2U3MYpA5cdO9eidjraO87W8mSVkIo77SNPtdNmNm31T33EFszX9mnbji8AFKCZka6jDsAHG%2BCga0yEkZCim%2Fw%3D%3D'

    holiday_2019 = []

    month = '06'  # 06 is June. or for all months, take upper for line.
    url = ' http://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getRestDeInfo?solYear=%s&solMonth=%s&ServiceKey=%s' % (
    year, month, mykey)

    get_data = requests.get(url)
    soup = BeautifulSoup(get_data.content, 'html.parser')
    table = soup.find_all('locdate')
    for i in table:
        holiday_2019.append(i.text)

    holiday_2019 = pd.to_datetime(holiday_2019)
    data['휴일변수'] = data['방송일시'].dt.weekday.isin([5, 6]).values | (data['방송일시'].dt.date.isin(holiday_2019.date)).astype(
        int)

    data['요일변수'] = data['방송일시'].dt.weekday

    data['주말변수'] = data['요일변수'].isin([5, 6]).values

    data['월급일변수'] = data['방송일시'].dt.day.isin([10, 17, 20, 25])

    df = pd.DataFrame(data.loc[data['방송일시'].dt.date.drop_duplicates().index][['휴일변수', '방송일시']])

    df.reset_index(drop=True, inplace=True)

    df['count'] = df.groupby((df['휴일변수'] != df['휴일변수'].shift(1)).cumsum()).cumcount() + 1

    date = df.loc[(df['count'] >= 3) & (df['휴일변수'] == True)]['방송일시'].dt.date.values

    adddate = pd.to_datetime(
        ['2019-02-02', '2019-02-03', '2019-03-01', '2019-03-02', '2019-05-04', '2019-05-05', '2019-09-12',
         '2019-09-13']).date

    data['연속휴일변수'] = data['방송일시']

    data['연속휴일변수'].loc[(data['방송일시'].dt.date.isin(date)) | (data['방송일시'].dt.date.isin(adddate))] = True
    data['연속휴일변수'].loc[~(data['방송일시'].dt.date.isin(date)) | (data['방송일시'].dt.date.isin(adddate))] = False

    data['사분기변수'] = data['방송일시'].dt.quarter - 1

    data['반기별변수'] = data['방송일시'].dt.month.isin(['7', '8', '9', '10', '11', '12'])

    data['계절변수'] = data['방송일시']

    data['계절변수'].loc[(data['방송일시'].dt.month.isin(['3', '4', '5']))] = 0
    data['계절변수'].loc[(data['방송일시'].dt.month.isin(['6', '7', '8']))] = 1
    data['계절변수'].loc[(data['방송일시'].dt.month.isin(['9', '10', '11']))] = 2
    data['계절변수'].loc[(data['방송일시'].dt.month.isin(['12', '1', '2']))] = 3

    data.to_csv(output_path)