def appliance_feature(dt):
    '''
    브랜드, 상품종류, 결제방식 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('삼성'), '브랜드'] = '삼성'
    dt.loc[dt['상품명'].str.contains('LG'), '브랜드'] = 'LG'

    dt['상품종류'] = '기타'
    dt.loc[dt['상품명'].str.contains('세탁기'), '상품종류'] = '세탁기'
    dt.loc[dt['상품명'].str.contains('냉장고'), '상품종류'] = '냉장고'
    dt.loc[dt['상품명'].str.contains('TV'), '상품종류'] = 'TV'
    dt.loc[dt['상품명'].str.contains('노트북'), '상품종류'] = '노트북'
    dt.loc[dt['상품명'].str.contains('공기청정기'), '상품종류'] = '공기청정기'
    dt.loc[dt['상품명'].str.contains('건조기'), '상품종류'] = '건조기'
    dt.loc[dt['상품명'].str.contains('청소기'), '상품종류'] = '청소기'
    dt.loc[dt['상품명'].str.contains('에어컨'), '상품종류'] = '에어컨'

    dt['결제방식'] = '무관'
    dt.loc[dt['상품명'].str.contains('무이자'), '결제방식'] = '무이자'
    dt.loc[dt['상품명'].str.contains('일시불'), '결제방식'] = '일시불'

    return dt


def furniture_feature(dt):
    '''
    브랜드, 상품종류, 결제방식 추가 및 필요없는 데이터 삭제
    '''
    dt.drop(dt.index[(dt['방송일시'].str.contains('2019-09-22')) & (
            (dt['상품명'].str.contains("보루네오 델라 원목 베드룸 세트")) | (dt['상품명'].str.contains("보루네오 델라 원목 거실장")))],
            inplace=True)
    dt.drop(dt.index[(dt['방송일시'].str.contains('2019-11-15')) & (dt['상품명'] == "유캐슬 마리노 협탁")], inplace=True)
    dt.drop(dt.index[(dt['방송일시'].str.contains('2019-11-15')) & (dt['상품명'] == "유캐슬 마리노 침실가구 풀세트 (매트리스포함)")],
            inplace=True)
    dt.drop(dt.index[(dt['방송일시'].str.contains('2019-11-15')) & (dt['상품명'] == "유캐슬 마리노 침실가구 실속세트(매트리스X)")], inplace=True)
    dt.drop(dt.index[(dt['방송일시'].str.contains('2019-11-15')) & (dt['상품명'] == "유캐슬 마리노 화장대세트 _화장대+거울")], inplace=True)

    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('보루네오'), '브랜드'] = '보루네오'
    dt.loc[dt['상품명'].str.contains('삼익'), '브랜드'] = '삼익'
    dt.loc[dt['상품명'].str.contains('장수'), '브랜드'] = '장수'
    dt.loc[dt['상품명'].str.contains('한샘'), '브랜드'] = '한샘'
    dt.loc[dt['상품명'].str.contains('이누스바스'), '브랜드'] = '이누스바스'
    dt.loc[dt['상품명'].str.contains('이조농방'), '브랜드'] = '이조농방'
    dt.loc[dt['상품명'].str.contains('뉴 벨라홈'), '브랜드'] = '뉴 벨라홈'
    dt.loc[dt['상품명'].str.contains('유캐슬'), '브랜드'] = '유캐슬'

    dt['상품종류'] = '기타'
    dt.loc[dt['상품명'].str.contains('침대'), '상품종류'] = '침대'
    dt.loc[(dt['상품명'].str.contains('소파')) | (dt['상품명'].str.contains('리클라이너')) | (
        dt['상품명'].str.contains('흙카우치')), '상품종류'] = '소파'
    dt.loc[(dt['상품명'].str.contains('하이바스')) | (dt['상품명'].str.contains('이누스바스 시공패키지')), '상품종류'] = '욕실'
    dt.loc[dt['상품명'].str.contains('붙박이장'), '상품종류'] = '붙박이장'

    dt['결제방식'] = '무관'
    dt.loc[dt['상품명'].str.contains('\(일\)'), '결제방식'] = '일시불'
    dt.loc[dt['상품명'].str.contains('\(무\)'), '결제방식'] = '무이자'

    return dt


def health_feature(dt):
    '''
    브랜드, 상품종류, 결제방식 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('종근당'), '브랜드'] = '종근당'
    dt.loc[dt['상품명'].str.contains('광동'), '브랜드'] = '광동'
    dt.loc[dt['상품명'].str.contains('뉴트리원'), '브랜드'] = '뉴트리원'

    dt['상품종류'] = '기타'
    dt.loc[dt['상품명'].str.contains('구미'), '상품종류'] = '구미'
    dt.loc[dt['상품명'].str.contains('석류'), '상품종류'] = '석류'
    dt.loc[dt['상품명'].str.contains('루테인'), '상품종류'] = '루테인'
    dt.loc[(dt['상품명'].str.contains('프리바이오틱스')) | (dt['상품명'].str.contains('유산균')), '상품종류'] = '유산균'
    dt.loc[dt['상품명'].str.contains('홍삼'), '상품종류'] = '홍삼'

    dt['결제방식'] = '무관'
    dt.loc[(dt['상품명'].str.contains('\(일\)')) | (dt['상품명'].str.contains('일시불')), '결제방식'] = '일시불'
    dt.loc[(dt['상품명'].str.contains('\(무\)')) | (dt['상품명'].str.contains('무이자')), '결제방식'] = '무이자'

    return dt


def life_feature(dt):
    '''
    상품종류, 추가
    '''
    dt['상품종류'] = '기타'
    dt.loc[dt['상품명'].str.contains('안마의자'), '상품종류'] = '안마의자'
    dt.loc[dt['상품명'].str.contains('의자'), '상품종류'] = '의자'
    dt.loc[(dt['상품명'].str.contains('옷걸이')) | (dt['상품명'].str.contains('리빙박스')), '상품종류'] = '생활용품'
    dt.loc[dt['상품명'].str.contains('비데'), '상품종류'] = '비데'
    dt.loc[(dt['상품명'].str.contains('매트')) | (dt['상품명'].str.contains('카페트매트')) | (dt['상품명'].str.contains('온열매트')) \
           | (dt['상품명'].str.contains('온수매트')) | (dt['상품명'].str.contains('물매트')), '상품종류'] = '매트'
    dt.loc[(dt['상품명'].str.contains('통증패치')) | (dt['상품명'].str.contains('수액패치')) | (
        dt['상품명'].str.contains('동전패치')), '상품종류'] = '패치'
    dt.loc[(dt['상품명'].str.contains('벽지')) | (dt['상품명'].str.contains('단열벽지')), '상품종류'] = '벽지'
    dt.loc[(dt['상품명'].str.contains('테이블')) | (dt['상품명'].str.contains('교자상')) | (
        dt['상품명'].str.contains('의자')), '상품종류'] = '가구'
    dt.loc[(dt['상품명'].str.contains('마사지')) | (dt['상품명'].str.contains('손안마기')), '상품종류'] = '마사지'
    dt.loc[dt['상품명'].str.contains('마스크'), '상품종류'] = '마스크'
    dt.loc[(dt['상품명'].str.contains('선풍기')) | (dt['상품명'].str.contains('서큘레이터')) | (dt['상품명'].str.contains('써큘레이터')) \
           | (dt['상품명'].str.contains('에어컨')) | (dt['상품명'].str.contains('원큘레이터')) | (
               dt['상품명'].str.contains('에어쿨러')), '상품종류'] = '냉방'
    dt.loc[(dt['상품명'].str.contains('매트릭스')) | (dt['상품명'].str.contains('메모리폼')), '상품종류'] = '매트릭스'
    dt.loc[dt['상품명'].str.contains('샤워기'), '상품종류'] = '욕실'
    dt.loc[(dt['상품명'].str.contains('청소기')) | (dt['상품명'].str.contains('로봇청소기')), '상품종류'] = '청소기'
    dt.loc[(dt['상품명'].str.contains('세제')) | (dt['상품명'].str.contains('섬유유연제')) | (dt['상품명'].str.contains('건조대')) \
           | (dt['상품명'].str.contains('빨래 삶통')) | (dt['상품명'].str.contains('화이트업')), '상품종류'] = '세탁'
    dt.loc[(dt['상품명'].str.contains('플래티늄')) | (dt['상품명'].str.contains('스쿼트머신')) \
           | (dt['상품명'].str.contains('워킹머신')), '상품종류'] = '운동기구'
    dt.loc[dt['상품명'].str.contains('이볼브'), '상품종류'] = '금고'

    return dt


def agriculture_feature(dt):
    '''
    상품종류 추가
    '''
    dt['상품종류'] = '기타'
    dt.loc[(dt['상품명'].str.contains('탕')) | (dt['상품명'].str.contains('구이')) | (dt['상품명'].str.contains('곱창')) \
           | (dt['상품명'].str.contains('아구채')) | (dt['상품명'].str.contains('장조림')) | (dt['상품명'].str.contains('배즙')) \
           | (dt['상품명'].str.contains('요일')) | (dt['상품명'].str.contains('두유')) | (dt['상품명'].str.contains('곡물그대로')) \
           | (dt['상품명'].str.contains('철판')) | (dt['상품명'].str.contains('재첩국')) | (dt['상품명'].str.contains('젓갈')) \
           | (dt['상품명'].str.contains('김치')) | (dt['상품명'].str.contains('강정')) | (dt['상품명'].str.contains('머루원액')) \
           | (dt['상품명'].str.contains('갈비탕')) | (dt['상품명'].str.contains('부각')) | (dt['상품명'].str.contains('떡')) \
           | (dt['상품명'].str.contains('쥐포')) | (dt['상품명'].str.contains('식탁앤김')) | (dt['상품명'].str.contains('양갱')) \
           | (dt['상품명'].str.contains('소한마리')) | (dt['상품명'].str.contains('선식')) | (dt['상품명'].str.contains('국밥')) \
           | (dt['상품명'].str.contains('낙곱새')) | (dt['상품명'].str.contains('곤드레')) | (dt['상품명'].str.contains('매실')) \
           | (dt['상품명'].str.contains('스테이크')) | (dt['상품명'].str.contains('닭발')) | (dt['상품명'].str.contains('감말랭이')) \
           | (dt['상품명'].str.contains('콩국수')) | (dt['상품명'].str.contains('호빵')) | (dt['상품명'].str.contains('냉면')) \
           | (dt['상품명'].str.contains('만두')) | (dt['상품명'].str.contains('마시는한끼')) | (dt['상품명'].str.contains('쥐치포')) \
           | (dt['상품명'].str.contains('육포')) | (dt['상품명'].str.contains('갓바위')) | (dt['상품명'].str.contains('더덕무침')) \
           | (dt['상품명'].str.contains('해장국')), '상품종류'] = '가공'

    dt.loc[(dt['상품명'].str.contains('옥수수')) | (dt['상품명'].str.contains('아카시아꿀')) | (dt['상품명'].str.contains('샤인머스켓')) \
           | (dt['상품명'].str.contains('쌀')) | (dt['상품명'].str.contains('시래기')) | (dt['상품명'].str.contains('사과')) \
           | (dt['상품명'].str.contains('고구마')) | (dt['상품명'].str.contains('고춧가루')) | (dt['상품명'].str.contains('두부')) \
           | (dt['상품명'].str.contains('한라봉')) | (dt['상품명'].str.contains('메주')) | (dt['상품명'].str.contains('오렌지')) \
           | (dt['상품명'].str.contains('벌꿀')) | (dt['상품명'].str.contains('키위')) | (
               dt['상품명'].str.contains('감귤')), '상품종류'] = '농산'

    dt.loc[(dt['상품명'].str.contains('수산물')) | (dt['상품명'].str.contains('생선')) | (dt['상품명'].str.contains('옥돔')) \
           | (dt['상품명'].str.contains('굴비')) | (dt['상품명'].str.contains('참굴')) | (dt['상품명'].str.contains('가자미')) \
           | (dt['상품명'].str.contains('갑오징어')) | (dt['상품명'].str.contains('오징어')) | (dt['상품명'].str.contains('꼬막')) \
           | (dt['상품명'].str.contains('새우')) | (dt['상품명'].str.contains('홍어')) | (dt['상품명'].str.contains('골뱅이')) \
           | (dt['상품명'].str.contains('조기')) | (dt['상품명'].str.contains('문어')) | (dt['상품명'].str.contains('꽃게')) \
           | (dt['상품명'].str.contains('장어')) | (dt['상품명'].str.contains('고등어')) | (dt['상품명'].str.contains('전복')) \
           | (dt['상품명'].str.contains('대구')) | (dt['상품명'].str.contains('랍스터')) | (dt['상품명'].str.contains('매생이')) \
           | (dt['상품명'].str.contains('갈치')) | (dt['상품명'].str.contains('낙지')) | (dt['상품명'].str.contains('다시')) \
           | (dt['상품명'].str.contains('과메기')) | (dt['상품명'].str.contains('황태')) | (dt['상품명'].str.contains('병어')) \
           | (dt['상품명'].str.contains('참돔')) | (dt['상품명'].str.contains('우럭')) | (
               dt['상품명'].str.contains('메로')), '상품종류'] = '수산'

    dt.loc[(dt['상품명'].str.contains('소갈비살')) | (dt['상품명'].str.contains('LA갈비')) | (dt['상품명'].str.contains('오리')) \
           | (dt['상품명'].str.contains('돼지')) | (dt['상품명'].str.contains('치마살')) | (dt['상품명'].str.contains('한우 한판')) \
           | (dt['상품명'].str.contains('우삼겹')) | (dt['상품명'].str.contains('안창살')) | (
               dt['상품명'].str.contains('우삽겹')) | (dt['상품명'].str.contains('뒷고기')), '상품종류'] = '축산'

    return dt


def clothing_feature(dt):
    '''
    브랜드, 상품종류 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('디즈니'), '브랜드'] = '디즈니'
    dt.loc[dt['상품명'].str.contains('유리진'), '브랜드'] = '유리진'
    dt.loc[dt['상품명'].str.contains('페플럼제이'), '브랜드'] = '페플럼제이'
    dt.loc[dt['상품명'].str.contains('헤스티지'), '브랜드'] = '헤스티지'
    dt.loc[dt['상품명'].str.contains('EXR'), '브랜드'] = 'EXR'
    dt.loc[dt['상품명'].str.contains('K-SWISS'), '브랜드'] = 'K-SWISS'
    dt.loc[dt['상품명'].str.contains('USPA'), '브랜드'] = 'USPA'
    dt.loc[dt['상품명'].str.contains('마리노블'), '브랜드'] = '마리노블'
    dt.loc[dt['상품명'].str.contains('그렉노먼'), '브랜드'] = '그렉노먼'
    dt.loc[dt['상품명'].str.contains('대동모피'), '브랜드'] = '대동모피'
    dt.loc[dt['상품명'].str.contains('더블유베일'), '브랜드'] = '더블유베일'
    dt.loc[dt['상품명'].str.contains('도네이'), '브랜드'] = '도네이'
    dt.loc[dt['상품명'].str.contains('디베이지'), '브랜드'] = '디베이지'
    dt.loc[dt['상품명'].str.contains('디키즈'), '브랜드'] = '디키즈'
    dt.loc[dt['상품명'].str.contains('라라쎄'), '브랜드'] = '라라쎄'
    dt.loc[dt['상품명'].str.contains('레드캠프'), '브랜드'] = '레드캠프'
    dt.loc[dt['상품명'].str.contains('로이몬스터'), '브랜드'] = '로이몬스터'
    dt.loc[dt['상품명'].str.contains('루이바셋'), '브랜드'] = '루이바셋'
    dt.loc[dt['상품명'].str.contains('르까프'), '브랜드'] = '르까프'
    dt.loc[dt['상품명'].str.contains('릴리젼'), '브랜드'] = '릴리젼'
    dt.loc[dt['상품명'].str.contains('마담팰리스'), '브랜드'] = '마담팰리스'
    dt.loc[dt['상품명'].str.contains('마르엘라로사티'), '브랜드'] = '마르엘라로사티'
    dt.loc[dt['상품명'].str.contains('마모트'), '브랜드'] = '마모트'
    dt.loc[dt['상품명'].str.contains('메시제이'), '브랜드'] = '메시제이'
    dt.loc[dt['상품명'].str.contains('메이듀'), '브랜드'] = '메이듀'
    dt.loc[dt['상품명'].str.contains('뱅뱅'), '브랜드'] = '뱅뱅'
    dt.loc[dt['상품명'].str.contains('보코'), '브랜드'] = '보코'
    dt.loc[dt['상품명'].str.contains('스텔라테일러'), '브랜드'] = '스텔라테일러'
    dt.loc[dt['상품명'].str.contains('스튜디오럭스'), '브랜드'] = '스튜디오럭스'
    dt.loc[dt['상품명'].str.contains('아리스토우'), '브랜드'] = '아리스토우'
    dt.loc[dt['상품명'].str.contains('아문센'), '브랜드'] = '아문센'
    dt.loc[dt['상품명'].str.contains('아주아'), '브랜드'] = '아주아'
    dt.loc[dt['상품명'].str.contains('알렉스하운드'), '브랜드'] = '알렉스하운드'
    dt.loc[dt['상품명'].str.contains('어반시크릿'), '브랜드'] = '어반시크릿'
    dt.loc[dt['상품명'].str.contains('에르나벨'), '브랜드'] = '에르나벨'
    dt.loc[dt['상품명'].str.contains('엔셀라두스'), '브랜드'] = '엔셀라두스'
    dt.loc[dt['상품명'].str.contains('오렐리안'), '브랜드'] = '오렐리안'
    dt.loc[dt['상품명'].str.contains('이동수골프'), '브랜드'] = '이동수골프'
    dt.loc[dt['상품명'].str.contains('임페리얼'), '브랜드'] = '임페리얼'
    dt.loc[dt['상품명'].str.contains('젠트웰'), '브랜드'] = '젠트웰'
    dt.loc[dt['상품명'].str.contains('코몽트'), '브랜드'] = '코몽트'
    dt.loc[dt['상품명'].str.contains('코펜하겐럭스'), '브랜드'] = '코펜하겐럭스'
    dt.loc[dt['상품명'].str.contains('크리스티나앤코'), '브랜드'] = '크리스티나앤코'
    dt.loc[dt['상품명'].str.contains('타운젠트'), '브랜드'] = '타운젠트'
    dt.loc[dt['상품명'].str.contains('테이트'), '브랜드'] = '테이트'
    dt.loc[dt['상품명'].str.contains('팜스프링스'), '브랜드'] = '팜스프링스'
    dt.loc[dt['상품명'].str.contains('헤비추얼'), '브랜드'] = '헤비추얼'
    dt.loc[dt['상품명'].str.contains('PAT'), '브랜드'] = 'PAT'
    dt.loc[dt['상품명'].str.contains('NNF'), '브랜드'] = 'NNF'

    dt['상품종류'] = '기타'

    dt.loc[dt['상품명'].str.contains('수트'), '상품종류'] = '정장'
    dt.loc[(dt['상품명'].str.contains('트랙수트')) | (dt['상품명'].str.contains('멀티웨어')), '상품종류'] = '운동'
    dt.loc[(dt['상품명'].str.contains('코트')) | (dt['상품명'].str.contains('롱코트')) | (
        dt['상품명'].str.contains('벤치코트')), '상품종류'] = '코트'
    dt.loc[(dt['상품명'].str.contains('패딩')) | (dt['상품명'].str.contains('구스다운')), '상품종류'] = '패딩'
    dt.loc[(dt['상품명'].str.contains('자켓')) | (dt['상품명'].str.contains('재킷')) | (dt['상품명'].str.contains('윈드브레이커')) \
           | (dt['상품명'].str.contains('핫멜트')) | (dt['상품명'].str.contains('니트점퍼')), '상품종류'] = '자켓'
    dt.loc[dt['상품명'].str.contains('베스트'), '상품종류'] = '베스트'
    dt.loc[dt['상품명'].str.contains('블라우스'), '상품종류'] = '블라우스'
    dt.loc[dt['상품명'].str.contains('셔츠'), '상품종류'] = '셔츠'
    dt.loc[(dt['상품명'].str.contains('맨투맨')) | (dt['상품명'].str.contains('티셔츠')) | (dt['상품명'].str.contains('약기모티')) \
           | (dt['상품명'].str.contains('모크넥')), '상품종류'] = '티셔츠'
    dt.loc[(dt['상품명'].str.contains('터틀넥')) | (dt['상품명'].str.contains('니트')) | (
        dt['상품명'].str.contains('스웨터')), '상품종류'] = '니트'
    dt.loc[(dt['상품명'].str.contains('밴딩팬츠')) | (dt['상품명'].str.contains('팬츠')) | (dt['상품명'].str.contains('라인핏')) \
           | (dt['상품명'].str.contains('레깅스')), '상품종류'] = '바지'
    dt.loc[(dt['상품명'].str.contains('데님팬츠')) | (dt['상품명'].str.contains('데님')), '상품종류'] = '청바지'
    dt.loc[dt['상품명'].str.contains('무스탕'), '상품종류'] = '무스탕'
    dt.loc[(dt['상품명'].str.contains('풀코디')) | (dt['상품명'].str.contains('앙상블')) | (
        dt['상품명'].str.contains('세트')), '상품종류'] = '세트'
    dt.loc[dt['상품명'].str.contains('원피스'), '상품종류'] = '원피스'
    dt.loc[dt['상품명'].str.contains('밍크'), '상품종류'] = '밍크'

    return dt


def beauty_feature(dt):
    '''
    브랜드, 상품종류 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('보닌'), '브랜드'] = '보닌'
    dt.loc[dt['상품명'].str.contains('더블모'), '브랜드'] = '더셀제프'
    dt.loc[dt['상품명'].str.contains('셀럽by재클린'), '브랜드'] = '더셀제프'
    dt.loc[dt['상품명'].str.contains('제니하우스'), '브랜드'] = '더셀제프'
    dt.loc[dt['상품명'].str.contains('프리지아'), '브랜드'] = '더셀제프'
    dt.loc[dt['상품명'].str.contains('아이앤아이'), '브랜드'] = '아이앤래쉬'
    dt.loc[dt['상품명'].str.contains('래쉬톡'), '브랜드'] = '아이앤래쉬'
    dt.loc[dt['상품명'].str.contains('시크릿'), '브랜드'] = '시크바비'
    dt.loc[dt['상품명'].str.contains('바비리스'), '브랜드'] = '시크바비'
    dt.loc[dt['상품명'].str.contains('블링썸'), '브랜드'] = '블링썸'
    dt.loc[dt['상품명'].str.contains('비버리'), '브랜드'] = '비버리'
    dt.loc[dt['상품명'].str.contains('에이유플러스'), '브랜드'] = '에이유플러스'
    dt.loc[dt['상품명'].str.contains('엘렌실라'), '브랜드'] = '엘렌끌레'
    dt.loc[dt['상품명'].str.contains('끌레드벨'), '브랜드'] = '엔렌끌레'
    dt.loc[dt['상품명'].str.contains('아미니'), '브랜드'] = '아미족'
    dt.loc[dt['상품명'].str.contains('족선생'), '브랜드'] = '아미족'
    dt.loc[dt['상품명'].str.contains('참존'), '브랜드'] = '참존'
    dt.loc[dt['상품명'].str.contains('바바코코'), '브랜드'] = '바바코코'
    dt.loc[dt['상품명'].str.contains('프리미엄 클린샤워'), '브랜드'] = '노브랜드'

    dt['상품종류'] = '기타'

    dt.loc[(dt['상품명'].str.contains('기초세트')) | (dt['상품명'].str.contains('에센스')) | (dt['상품명'].str.contains('선스틱')) \
           | (dt['상품명'].str.contains('썬스틱')) | (dt['상품명'].str.contains('세럼')) | (dt['상품명'].str.contains('크림')) \
           | (dt['상품명'].str.contains('클렌져')) | (dt['상품명'].str.contains('클렌징패드')), '상품종류'] = '기초화장품'
    dt.loc[(dt['상품명'].str.contains('파운데이션')) | (dt['상품명'].str.contains('아이라이너')) | (dt['상품명'].str.contains('아이스타일러')) \
           | (dt['상품명'].str.contains('쿠션')) | (dt['상품명'].str.contains('커버팩트')), '상품종류'] = '화장품'
    dt.loc[dt['상품명'].str.contains('속눈썹'), '상품종류'] = '속눈썹'
    dt.loc[dt['상품명'].str.contains('샴푸'), '상품종류'] = '샴푸'
    dt.loc[(dt['상품명'].str.contains('틴트')) | (dt['상품명'].str.contains('립스틱')), '상품종류'] = '틴트'
    dt.loc[(dt['상품명'].str.contains('염색')) | (dt['상품명'].str.contains('헤어컬러')) | (dt['상품명'].str.contains('뿌리펌')) \
           | (dt['상품명'].str.contains('셀프뿌리퍼머')), '상품종류'] = '염색'
    dt.loc[(dt['상품명'].str.contains('필링')) | (dt['상품명'].str.contains('에이지큐어')) | (dt['상품명'].str.contains('마스크팩')) \
           | (dt['상품명'].str.contains('마스크')) | (dt['상품명'].str.contains('모공기기관리세트')), '상품종류'] = '피부'
    dt.loc[(dt['상품명'].str.contains('풋샴푸')) | (dt['상품명'].str.contains('풋케어')), '상품종류'] = '발관리'
    dt.loc[(dt['상품명'].str.contains('샤워')) | (dt['상품명'].str.contains('오일워시')), '상품종류'] = '샤워'
    dt.loc[dt['상품명'].str.contains('젤네일스트립'), '상품종류'] = '손톱'
    dt.loc[(dt['상품명'].str.contains('고데기')) | (dt['상품명'].str.contains('고데롤')) | (
        dt['상품명'].str.contains('볼륨스타일러')), '상품종류'] = '헤어기기'

    return dt


def underwear_feature(dt):
    '''
    브랜드, 상품종류, 성별 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('헤드'), '브랜드'] = '스포츠'
    dt.loc[dt['상품명'].str.contains('프로스펙스'), '브랜드'] = '스포츠'
    dt.loc[dt['상품명'].str.contains('카파'), '브랜드'] = '스포츠'
    dt.loc[dt['상품명'].str.contains('푸마'), '브랜드'] = '스포츠'
    dt.loc[dt['상품명'].str.contains('에버라스트'), '브랜드'] = '에버보디'
    dt.loc[dt['상품명'].str.contains('보디가드'), '브랜드'] = '에버보디'
    dt.loc[dt['상품명'].str.contains('실크트리'), '브랜드'] = '실크자연'
    dt.loc[dt['상품명'].str.contains('자연감성'), '브랜드'] = '실크자연'
    dt.loc[dt['상품명'].str.contains('라쉬반'), '브랜드'] = '라쉬반'
    dt.loc[dt['상품명'].str.contains('레이프릴'), '브랜드'] = '레이프릴'
    dt.loc[dt['상품명'].str.contains('루시헨느'), '브랜드'] = '루시헨느'
    dt.loc[dt['상품명'].str.contains('몬테밀라노'), '브랜드'] = '몬테밀라노'
    dt.loc[dt['상품명'].str.contains('발레리'), '브랜드'] = '발레리'
    dt.loc[dt['상품명'].str.contains('벨레즈온'), '브랜드'] = '벨레즈온'
    dt.loc[dt['상품명'].str.contains('아키'), '브랜드'] = '아키'
    dt.loc[dt['상품명'].str.contains('오렐리안'), '브랜드'] = '오렐리안'
    dt.loc[dt['상품명'].str.contains('쿠미투니카'), '브랜드'] = '쿠미투니카'

    dt['상품종류'] = '기타'

    dt.loc[(dt['상품명'].str.contains('패키지')) | (dt['상품명'].str.contains('반팔상하세트')) | (
        dt['상품명'].str.contains('세트')), '상품종류'] = '세트'
    dt.loc[dt['상품명'].str.contains('언더셔츠'), '상품종류'] = '언더셔츠'
    dt.loc[(dt['상품명'].str.contains('드로즈')) | (dt['상품명'].str.contains('트렁크')), '상품종류'] = '남성팬티'
    dt.loc[(dt['상품명'].str.contains('매직니퍼팬티')) | (dt['상품명'].str.contains('거들팬티')), '상품종류'] = '여성팬티'
    dt.loc[(dt['상품명'].str.contains('런닝')) | (dt['상품명'].str.contains('언더탑')), '상품종류'] = '남성런닝'
    dt.loc[(dt['상품명'].str.contains('보정런닝')) | (dt['상품명'].str.contains('이지탑')), '상품종류'] = '여성런닝'
    dt.loc[(dt['상품명'].str.contains('란쥬')) | (dt['상품명'].str.contains('쉐이퍼')) | (
        dt['상품명'].str.contains('슬리머')), '상품종류'] = '란제리'
    dt.loc[(dt['상품명'].str.contains('브라')) | (dt['상품명'].str.contains('브라탑')) | (dt['상품명'].str.contains('브라렛')) \
           | (dt['상품명'].str.contains('보정브라')), '상품종류'] = '브라'
    dt.loc[dt['상품명'].str.contains('브라팬티'), '상품종류'] = '여성속옷세트'
    dt.loc[(dt['상품명'].str.contains('이지웨어')) | (dt['상품명'].str.contains('원피스')), '상품종류'] = '원피스'
    dt.loc[(dt['상품명'].str.contains('이너웨어')) | (dt['상품명'].str.contains('동내의')) | (dt['상품명'].str.contains('웜웨어')) \
           | (dt['상품명'].str.contains('기모')), '상품종류'] = '내복'
    dt.loc[dt['상품명'].str.contains('레깅스'), '상품종류'] = '레깅스'

    dt['성별'] = '기타'

    dt.loc[(dt['상품명'].str.contains('남성')) | (dt['상품명'].str.contains('머슬')) | (dt['상품명'].str.contains('남아')) \
           | (dt['상품명'].str.contains('언더셔츠')) | (dt['상품명'].str.contains('드로즈')) | (dt['상품명'].str.contains('트렁크')) \
           | (dt['상품명'].str.contains('런닝')) | (dt['상품명'].str.contains('언더탑')), '성별'] = '남성'
    dt.loc[(dt['상품명'].str.contains('여성')) | (dt['상품명'].str.contains('여아')) | (dt['상품명'].str.contains('이너웨어')) \
           | (dt['상품명'].str.contains('슬리머')) | (dt['상품명'].str.contains('매직니퍼팬티')) | (dt['상품명'].str.contains('거들팬티')) \
           | (dt['상품명'].str.contains('보정런닝')) | (dt['상품명'].str.contains('이지탑')) | (dt['상품명'].str.contains('란쥬')) \
           | (dt['상품명'].str.contains('쉐이퍼')) | (dt['상품명'].str.contains('브라')) | (dt['상품명'].str.contains('브라탑')) \
           | (dt['상품명'].str.contains('브라렛')) | (dt['상품명'].str.contains('보정브라')) | (dt['상품명'].str.contains('브라팬티')) \
           | (dt['상품명'].str.contains('이지웨어')) | (dt['상품명'].str.contains('원피스')) | (
               dt['상품명'].str.contains('레깅스')), '성별'] = '여성'

    return dt


def accessory_feature(dt):
    '''
    브랜드, 상품종류 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('루이띠에'), '브랜드'] = '루이띠에'
    dt.loc[dt['상품명'].str.contains('구찌'), '브랜드'] = '구찌'
    dt.loc[dt['상품명'].str.contains('기라로쉬'), '브랜드'] = '기라로쉬'
    dt.loc[dt['상품명'].str.contains('레노마'), '브랜드'] = '레노레비'
    dt.loc[dt['상품명'].str.contains('레비노블'), '브랜드'] = '레노레비'
    dt.loc[dt['상품명'].str.contains('버버리'), '브랜드'] = '버버리'
    dt.loc[dt['상품명'].str.contains('로베르타'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('엘르'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('삭루츠'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('칼리베이직'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('도스문도스'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('소노비'), '브랜드'] = '로베엘르'
    dt.loc[dt['상품명'].str.contains('시스마르스'), '브랜드'] = '시스마르스'
    dt.loc[dt['상품명'].str.contains('아가타'), '브랜드'] = '아가타'
    dt.loc[dt['상품명'].str.contains('에버라스트'), '브랜드'] = '에버라스트'
    dt.loc[dt['상품명'].str.contains('엘르'), '브랜드'] = '엘르'
    dt.loc[dt['상품명'].str.contains('오델로'), '브랜드'] = '오델로'
    dt.loc[dt['상품명'].str.contains('월드컵'), '브랜드'] = '월드컵'
    dt.loc[dt['상품명'].str.contains('엘리자베스아덴'), '브랜드'] = '엘리로베'
    dt.loc[dt['상품명'].str.contains('로베르타'), '브랜드'] = '엘리로베'
    dt.loc[dt['상품명'].str.contains('기라로쉬'), '브랜드'] = '엘리로베'
    dt.loc[dt['상품명'].str.contains('페리엘리스'), '브랜드'] = '엘리로베'
    dt.loc[dt['상품명'].str.contains('프라다'), '브랜드'] = '프라생로'
    dt.loc[dt['상품명'].str.contains('생로랑'), '브랜드'] = '프라생로'
    dt.loc[dt['상품명'].str.contains('DIOR'), '브랜드'] = '프라생로'
    dt.loc[dt['상품명'].str.contains('톰포드'), '브랜드'] = '프라생로'
    dt.loc[dt['상품명'].str.contains('페라가모'), '브랜드'] = '프라생로'
    dt.loc[dt['상품명'].str.contains('AAA'), '브랜드'] = 'AAA'
    dt.loc[dt['상품명'].str.contains('트레스패스'), '브랜드'] = '트레레코'
    dt.loc[dt['상품명'].str.contains('레코바'), '브랜드'] = '트레레코'
    dt.loc[dt['상품명'].str.contains('W클라우드'), '브랜드'] = '트레레코'

    dt['상품종류'] = '기타'

    dt.loc[dt['상품명'].str.contains('목걸이'), '상품종류'] = '목걸이'
    dt.loc[dt['상품명'].str.contains('팔찌'), '상품종류'] = '팔찌'
    dt.loc[dt['상품명'].str.contains('반지'), '상품종류'] = '반지'
    dt.loc[dt['상품명'].str.contains('선글라스'), '상품종류'] = '선글라스'
    dt.loc[dt['상품명'].str.contains('지갑'), '상품종류'] = '지갑'
    dt.loc[(dt['상품명'].str.contains('투웨이백')) | (dt['상품명'].str.contains('크로스백')) | (dt['상품명'].str.contains('토트백')) \
           | (dt['상품명'].str.contains('버킷백')) | (dt['상품명'].str.contains('숄더백')) | (dt['상품명'].str.contains('클러치백')) | (
               dt['상품명'].str.contains('백팩')) \
           | (dt['상품명'].str.contains('샤첼')) | (dt['상품명'].str.contains('체인 숄더')) | (dt['상품명'].str.contains('패브릿백')) \
           | (dt['상품명'].str.contains('카메라백')) | (dt['상품명'].str.contains('체인백')), '상품종류'] = '가방'
    dt.loc[dt['상품명'].str.contains('스카프'), '상품종류'] = '스카프'
    dt.loc[dt['상품명'].str.contains('양산'), '상품종류'] = '양산'
    dt.loc[(dt['상품명'].str.contains('스니커즈')) | (dt['상품명'].str.contains('슬립온')), '상품종류'] = '스니커즈'
    dt.loc[(dt['상품명'].str.contains('러닝화')) | (dt['상품명'].str.contains('트레킹화')) | (
        dt['상품명'].str.contains('워킹화')), '상품종류'] = '운동화'
    dt.loc[dt['상품명'].str.contains('펌프스'), '상품종류'] = '펌프스'
    dt.loc[dt['상품명'].str.contains('샌들'), '상품종류'] = '샌들'
    dt.loc[dt['상품명'].str.contains('모자'), '상품종류'] = '모자'

    return dt


def kitchen_feature(dt):
    '''
    브랜드, 상품종류 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('락앤락'), '브랜드'] = '락앤제오'
    dt.loc[dt['상품명'].str.contains('제오닉'), '브랜드'] = '락앤제오'
    dt.loc[dt['상품명'].str.contains('램프쿡'), '브랜드'] = '램프쿡'
    dt.loc[dt['상품명'].str.contains('린나이'), '브랜드'] = '린나이'
    dt.loc[dt['상품명'].str.contains('매직쉐프'), '브랜드'] = '매직쉐프'
    dt.loc[dt['상품명'].str.contains('올리고'), '브랜드'] = '올리고'
    dt.loc[dt['상품명'].str.contains('am마카롱'), '브랜드'] = 'am마카롱'
    dt.loc[dt['상품명'].str.contains('쿠진나이프케어'), '브랜드'] = '쿠진나이프케어'
    dt.loc[dt['상품명'].str.contains('파뷔에'), '브랜드'] = '파뷔에독일'
    dt.loc[dt['상품명'].str.contains('독일지니어스정품'), '브랜드'] = '파뷔에독일'
    dt.loc[dt['상품명'].str.contains('프로피쿡'), '브랜드'] = '프로피쿡'
    dt.loc[dt['상품명'].str.contains('한일'), '브랜드'] = '한일'
    dt.loc[dt['상품명'].str.contains('쿠쿠'), '브랜드'] = '쿠쿠'
    dt.loc[dt['상품명'].str.contains('PN'), '브랜드'] = 'PN'

    dt['상품종류'] = '기타'

    dt.loc[dt['상품명'].str.contains('칼'), '상품종류'] = '칼'
    dt.loc[dt['상품명'].str.contains('밀폐용기'), '상품종류'] = '밀폐용기'
    dt.loc[dt['상품명'].str.contains('냄비'), '상품종류'] = '냄비'
    dt.loc[dt['상품명'].str.contains('솥'), '상품종류'] = '밥솥'
    dt.loc[dt['상품명'].str.contains('가스레인지'), '상품종류'] = '가스레인지'
    dt.loc[dt['상품명'].str.contains('전자레인지'), '상품종류'] = '전자레인지'
    dt.loc[dt['상품명'].str.contains('그릴레인지'), '상품종류'] = '그릴레인지'
    dt.loc[dt['상품명'].str.contains('텀블러'), '상품종류'] = '텀블러'
    dt.loc[(dt['상품명'].str.contains('다지기')) | (dt['상품명'].str.contains('블렌더')) | (
        dt['상품명'].str.contains('믹서기')), '상품종류'] = '믹서기'
    dt.loc[(dt['상품명'].str.contains('프라이팬')) | (dt['상품명'].str.contains('후라이팬')), '상품종류'] = '후라이팬'
    dt.loc[dt['상품명'].str.contains('살균건조기'), '상품종류'] = '살균건조기'
    dt.loc[dt['상품명'].str.contains('에어프라이어'), '상품종류'] = '에어프라이어'

    return dt


def bedding_feature(dt):
    '''
    브랜드, 상품종류 추가
    '''
    dt['브랜드'] = '기타'
    dt.loc[dt['상품명'].str.contains('보몽드'), '브랜드'] = '보몽드'
    dt.loc[dt['상품명'].str.contains('한샘'), '브랜드'] = '한샘지나'
    dt.loc[dt['상품명'].str.contains('지나송'), '브랜드'] = '한샘지나'
    dt.loc[dt['상품명'].str.contains('한스데코'), '브랜드'] = '한샘지나'
    dt.loc[dt['상품명'].str.contains('리앤코리아'), '브랜드'] = '리앤코리아'
    dt.loc[dt['상품명'].str.contains('한빛'), '브랜드'] = '한빛'
    dt.loc[dt['상품명'].str.contains('효재'), '브랜드'] = '효재'

    dt['상품종류'] = '기타'

    dt.loc[(dt['상품명'].str.contains('침구 풀세트')) | (dt['상품명'].str.contains('침구세트')), '상품종류'] = '침구'
    dt.loc[dt['상품명'].str.contains('커튼'), '상품종류'] = '커튼'
    dt.loc[dt['상품명'].str.contains('카페트'), '상품종류'] = '카패트'

    dt.drop(dt.index[dt['상품명'] == "안지 청풍 대자리"], inplace=True)

    return dt


def add_specified_feature(input_path='', output_path=''):
    '''
    :param input_path: 상품군으로 분리된 파일이 저장되어 있는 입력 파일 경로
    :param output_path: 출력 파일 경로
    :output: 상품군별 특성화된 변수 추가, 상품군 이름 + 2.csv 파일로 각 파일 신규 생성
    '''
    import pandas as pd

    dt = pd.read_csv(input_path + 'appliance.csv', index_col='Unnamed: 0')
    dt = appliance_feature(dt)
    dt.to_csv(output_path + 'appliance2.csv', index=True)

    dt = pd.read_csv(input_path + 'furniture.csv', index_col='Unnamed: 0')
    dt = furniture_feature(dt)
    dt.to_csv(output_path + 'furniture2.csv', index=True)

    dt = pd.read_csv(input_path + 'health.csv', index_col='Unnamed: 0')
    dt = health_feature(dt)
    dt.to_csv(output_path + 'health2.csv', index=True)

    dt = pd.read_csv(input_path + 'life.csv', index_col='Unnamed: 0')
    dt = life_feature(dt)
    dt.to_csv(output_path + 'life2.csv', index=True)

    dt = pd.read_csv(input_path + 'clothing.csv', index_col='Unnamed: 0')
    dt = clothing_feature(dt)
    dt.to_csv(output_path + 'clothing2.csv', index=True)

    dt = pd.read_csv(input_path + 'agriculture.csv', index_col='Unnamed: 0')
    dt = agriculture_feature(dt)
    dt.to_csv(output_path + 'agriculture2.csv', index=True)

    dt = pd.read_csv(input_path + 'underwear.csv', index_col='Unnamed: 0')
    dt = underwear_feature(dt)
    dt.to_csv(output_path + 'underwear2.csv', index=True)

    dt = pd.read_csv(input_path + 'beauty.csv', index_col='Unnamed: 0')
    dt = beauty_feature(dt)
    dt.to_csv(output_path + 'beauty2.csv', index=True)

    dt = pd.read_csv(input_path + 'accessory.csv', index_col='Unnamed: 0')
    dt = accessory_feature(dt)
    dt.to_csv(output_path + 'accessory2.csv', index=True)

    dt = pd.read_csv(input_path + 'kitchen.csv', index_col='Unnamed: 0')
    dt = kitchen_feature(dt)
    dt.to_csv(output_path + 'kitchen2.csv', index=True)

    dt = pd.read_csv(input_path + 'bedding.csv', index_col='Unnamed: 0')
    dt = bedding_feature(dt)
    dt.to_csv(output_path + 'bedding2.csv', index=True)