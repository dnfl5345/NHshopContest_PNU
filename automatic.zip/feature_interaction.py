def feature_interaction(path = ""):
    '''
    :param path: 입출력할 파일의 위치, dt_scaling의 data_scaling의 결과로 만들어진 file3.csv파일을 읽고, file_final.csv형식으로 저장.
    :output:
    1. 예측 과정에 필요없는 '방송일시', '노출(분)', '마더코드', '상품코드', '상품명', '상품군' 등의 column들을 drop
    2. 취급액과 상관관계가 음수인 경우 취급액과의 상관관계를 양수로 만들기 위해 역수를 씌워준 후, 값이 지나치게 커지는 것을 막기위해
        로그를 씌워줌.
    3. 판매단가를 minmax scaling 해줌
    4. column 2개를 선정해 더했을때, 취급액과의 상관관계가 개별적인 column보다 개선이 있을 경우, 기존 data에 column 2개를 더해 새롭게
       만든 column을 추가해줌.
    5. 4의 과정을 거쳐서 만든 data에서 다시 column 2개를 선정해 더했을 때, 기존 column보다 취급액과의 상관관계에 개선이 있고,
       그 상관관계가 0.4가 넘는 경우, 기존 data에 column 2개를 더한 column을 추가해줌.
    6. 판매단가를 제외하고, data에서 취급액과의 상관관계가 0.2 미만인 경우 drop 해줌.
    7. 위와 같은 과정을 거쳐 만든 data를 file_final.csv 형식으로 파일 저장. 추후 이 파일을 가지고 모델 학습
    '''
    import pandas as pd
    import numpy as np
    from sklearn.preprocessing import MinMaxScaler

    files = ['accessory', 'appliance', 'beauty', 'bedding', 'clothing', 'agriculture', 'furniture', 'health', 'kitchen',
             'life', 'underwear']

    for file in files:
        data = pd.read_csv(path + file + '3.csv', index_col='Unnamed: 0')
        data.drop(columns=['방송일시', '노출(분)', '마더코드', '상품코드', '상품명', '상품군'], inplace=True)

        scaler = MinMaxScaler()

        for col in data.columns:
            if data.corr().loc[col, '취급액'] >= 0 or col == '취급액':
                continue
            data[col] = (1 / (data[col] + 1e-3)).apply(np.log)
            data[col] = scaler.fit_transform(data[col].values.reshape(-1, 1)).ravel()

        drop_list = []
        for col in data.columns:
            if col == '판매단가':
                continue
            if data.corr().loc[col, '취급액'] < 0.1 or np.isnan(data.corr().loc[col, '취급액'] + 1):
                drop_list.append(col)

        data.drop(columns=drop_list, inplace=True)

        data['판매단가'] = scaler.fit_transform(data['판매단가'].values.reshape(-1, 1)).ravel()

        cols = data.columns
        for i in range(len(cols)):
            if cols[i] == '취급액':
                continue
            for j in range(i + 1, len(cols)):
                if cols[j] == '취급액':
                    continue
                temp = data.iloc[:, i] + data.iloc[:, j]
                if data['취급액'].corr(data.iloc[:, i]) < data['취급액'].corr(temp) and data['취급액'].corr(data.iloc[:, j]) < \
                        data['취급액'].corr(temp):
                    data[cols[i] + '+' + cols[j]] = temp

        cols = data.columns
        for i in range(len(cols)):
            if cols[i] == '취급액':
                continue
            for j in range(i + 1, len(cols)):
                if cols[j] == '취급액':
                    continue
                temp = data.iloc[:, i] + data.iloc[:, j]
                if data['취급액'].corr(data.iloc[:, i]) < data['취급액'].corr(temp) and data['취급액'].corr(data.iloc[:, j]) < \
                        data['취급액'].corr(temp) and data['취급액'].corr(temp) > 0.4:
                    data[cols[i] + '+' + cols[j]] = temp

        drop_list = []
        for col in data.columns:
            if col == '취급액' or col == '판매단가':
                continue
            if data['취급액'].corr(data[col]) < 0.2:
                drop_list.append(col)

        data.drop(columns=drop_list, inplace=True)

        data.to_csv(path + file + '_final.csv', index=True)



