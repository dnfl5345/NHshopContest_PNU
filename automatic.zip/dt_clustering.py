def clustering(input_path ='dt2.csv', output_path =""):
    '''
    :param input_path: 기존 데이터에 날짜관련 데이터가 추가된 파일
    :param output_path: 출력 파일 저장 경로
    :output: input_path의 파일을 각 상품군으로 분리하여 저장
    '''
    import pandas as pd
    data = pd.read_csv(input_path, index_col='Unnamed: 0')

    accessory = data[data['상품군'] == '잡화']
    accessory.to_csv(output_path + 'accessory.csv', index=True)

    agriculture = data[data['상품군'] == '농수축']
    agriculture.to_csv(output_path + 'agriculture.csv', index=True)

    appliance = data[data['상품군'] == '가전']
    appliance.to_csv(output_path + 'appliance.csv', index=True)

    beauty = data[data['상품군'] == '이미용']
    beauty.to_csv(output_path + 'beauty.csv', index=True)

    bedding = data[data['상품군'] == '침구']
    bedding.to_csv(output_path + 'bedding.csv', index=True)

    clothing = data[data['상품군'] == '의류']
    clothing.to_csv(output_path + 'clothing.csv', index=True)

    furniture = data[data['상품군'] == '가구']
    furniture.to_csv(output_path + 'furniture.csv', index=True)

    health = data[data['상품군'] == '건강기능']
    health.to_csv(output_path + 'health.csv', index=True)

    kitchen = data[data['상품군'] == '주방']
    kitchen.to_csv(output_path + 'kitchen.csv', index=True)

    life = data[data['상품군'] == '생활용품']
    life.to_csv(output_path + 'life.csv', index=True)

    underwear = data[data['상품군'] == '속옷']
    underwear.to_csv(output_path + 'underwear.csv', index=True)